from .GIN import Multi_GIN, GIN

__all__ = ['Multi_GIN', 'GIN']
