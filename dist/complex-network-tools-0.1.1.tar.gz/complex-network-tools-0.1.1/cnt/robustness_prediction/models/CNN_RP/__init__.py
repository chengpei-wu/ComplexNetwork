from .CNN_RP import CNN_RP

__all__ = ['CNN_RP']
