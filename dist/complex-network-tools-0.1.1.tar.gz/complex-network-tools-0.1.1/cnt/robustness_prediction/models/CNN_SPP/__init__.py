from .CNN_SPP import CNN_SPP

# from .SpatialPyramidPooling import SpatialPyramidPooling

__all__ = ['CNN_SPP']
