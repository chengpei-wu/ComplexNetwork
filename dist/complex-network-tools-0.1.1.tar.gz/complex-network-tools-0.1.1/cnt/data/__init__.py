import dgl.dataloading

dgl.dataloading.DataLoader