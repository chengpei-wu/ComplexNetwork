# todo: add simulated attacks
# todo: add spectral measurement
# todo: add others
